char unalChar(const unsigned char *adr);
short unalShort(const short unsigned int *adr);
