/*
 * fdk_aac_decoder.h
 *
 *  Created on: 08.05.2017
 *      Author: michaelboeckling
 */

#ifndef _INCLUDE_FDK_AAC_DECODER_H_
#define _INCLUDE_FDK_AAC_DECODER_H_

void fdkaac_decoder_task(void *pvParameters);

#endif /* _INCLUDE_FDK_AAC_DECODER_H_ */
